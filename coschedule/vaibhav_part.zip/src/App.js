import logo from './logo.svg';
import './App.css';
import MainRoutes from './Components/Routes/mainRoutes';

function App() {
  return (
    <div className="App">
        <MainRoutes />
    </div>
  );
}

export default App;
