import React from 'react'
import "./login.css"
const SideImage = () => {
  return (
    <div >
        <img className='zoom-in-out-box' src="https://accounts.coschedule.com/img/login-illustrations/14-bbd1fa4ef061b911e1b6a3107a65b8ee.png" 
        alt="" />
    </div>
  )
}

export default SideImage